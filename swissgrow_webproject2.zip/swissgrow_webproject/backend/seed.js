require("dotenv").config();
const mongoose = require("mongoose");
const Review = require("./models/Review");
const News = require("./models/News");
const Category = require("./models/Category");
const Fertilizer = require("./models/Fertilizer");

const seed = async () => {
  await mongoose.connect(process.env.MONGO_URI);

  await Review.deleteMany();
  await News.deleteMany();
  await Category.deleteMany();
  await Fertilizer.deleteMany();

  await Review.insertMany([
    { username: "Alice", comment: "Отличное удобрение!", rating: 5 },
    { username: "Bob", comment: "Хорошо работает", rating: 4 }
  ]);

  await News.insertMany([
    { title: "Новое поступление", content: "В продаже новые биоудобрения." },
    { title: "Скидки!", content: "Только в июле -20% на всю продукцию." }
  ]);

  const categories = await Category.insertMany([
    { name: "Органические", description: "Биоудобрения" },
    { name: "Минеральные", description: "Химические смеси" }
  ]);

  await Fertilizer.insertMany([
    { name: "Биогумус", description: "Экологично", category: categories[0]._id },
    { name: "Азофоска", description: "Минеральное удобрение", category: categories[1]._id }
  ]);

  console.log("База успешно заполнена!");
  mongoose.disconnect();
};

seed();