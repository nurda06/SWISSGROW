const mongoose = require('mongoose');

const fertilizerSchema = new mongoose.Schema({
  name: String,
  type: String,
  composition: String,
  stock: Number,
  dateAdded: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Fertilizer', fertilizerSchema);
