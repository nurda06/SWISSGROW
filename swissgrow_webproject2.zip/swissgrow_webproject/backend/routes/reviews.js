const express = require("express");
const router = express.Router();
const Review = require("../models/Review");

router.get("/", async (req, res) => {
  const reviews = await Review.find().sort({ createdAt: -1 });
  res.json(reviews);
});

router.post("/", async (req, res) => {
  const newReview = new Review(req.body);
  const saved = await newReview.save();
  res.status(201).json(saved);
});

module.exports = router;