const express = require('express');
const router = express.Router();
const Fertilizer = require('../models/Fertilizer');
const auth = require('../middleware/auth');

router.get('/', async (req, res) => {
  const data = await Fertilizer.find();
  res.json(data);
});

router.post('/', auth, async (req, res) => {
  const newFertilizer = new Fertilizer(req.body);
  await newFertilizer.save();
  res.status(201).json(newFertilizer);
});

router.put('/:id', auth, async (req, res) => {
  const updated = await Fertilizer.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

router.delete('/:id', auth, async (req, res) => {
  await Fertilizer.findByIdAndDelete(req.params.id);
  res.send('Deleted');
});

module.exports = router;
